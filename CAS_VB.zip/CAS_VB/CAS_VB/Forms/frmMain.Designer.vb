﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmMain
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmMain))
        Me.StatusStrip1 = New System.Windows.Forms.StatusStrip()
        Me.ToolStripStatusLabel1 = New System.Windows.Forms.ToolStripStatusLabel()
        Me.lblUserType = New System.Windows.Forms.ToolStripStatusLabel()
        Me.ToolStripStatusLabel2 = New System.Windows.Forms.ToolStripStatusLabel()
        Me.lblUser = New System.Windows.Forms.ToolStripStatusLabel()
        Me.ToolStripStatusLabel3 = New System.Windows.Forms.ToolStripStatusLabel()
        Me.lblDateTime = New System.Windows.Forms.ToolStripStatusLabel()
        Me.ToolStripStatusLabel4 = New System.Windows.Forms.ToolStripStatusLabel()
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip()
        Me.SchoolToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.SchoolRegistrationToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.DepartmentToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.DepartmentEntryToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.CourseStudyToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.LecturerToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.LecturerEntryToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.CourseToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.CourseRegistrationToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.StudentsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.StudentEntryToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ResultToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ResultEntryToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ResultsEntryToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ImportsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.MultipleToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.CoursesToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.LecturersToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ResultsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.StudentsToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.RecordsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.CoursesToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.LecturersToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.ResultsToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.StudentsToolStripMenuItem2 = New System.Windows.Forms.ToolStripMenuItem()
        Me.UtilitiesToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.UserRegistrationToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ChangePasswordToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.TransferStudentsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.CalculatorToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.NotepadToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.MSWordToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.WordToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.TaskManagerToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ReportsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.CoursesToolStripMenuItem2 = New System.Windows.Forms.ToolStripMenuItem()
        Me.LecturersToolStripMenuItem2 = New System.Windows.Forms.ToolStripMenuItem()
        Me.ResultsToolStripMenuItem2 = New System.Windows.Forms.ToolStripMenuItem()
        Me.StudentsToolStripMenuItem3 = New System.Windows.Forms.ToolStripMenuItem()
        Me.CourseToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.OverallToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.StudentsToolStripMenuItem4 = New System.Windows.Forms.ToolStripMenuItem()
        Me.HelpToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.AboutToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.LogoutToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
        Me.Timer2 = New System.Windows.Forms.Timer(Me.components)
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.StatusStrip1.SuspendLayout()
        Me.MenuStrip1.SuspendLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'StatusStrip1
        '
        Me.StatusStrip1.ImageScalingSize = New System.Drawing.Size(20, 20)
        Me.StatusStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ToolStripStatusLabel1, Me.lblUserType, Me.ToolStripStatusLabel2, Me.lblUser, Me.ToolStripStatusLabel3, Me.lblDateTime, Me.ToolStripStatusLabel4})
        Me.StatusStrip1.Location = New System.Drawing.Point(0, 687)
        Me.StatusStrip1.Name = "StatusStrip1"
        Me.StatusStrip1.Size = New System.Drawing.Size(1162, 25)
        Me.StatusStrip1.TabIndex = 3
        Me.StatusStrip1.Text = "StatusStrip1"
        '
        'ToolStripStatusLabel1
        '
        Me.ToolStripStatusLabel1.Font = New System.Drawing.Font("Segoe UI Semibold", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ToolStripStatusLabel1.Name = "ToolStripStatusLabel1"
        Me.ToolStripStatusLabel1.Size = New System.Drawing.Size(101, 20)
        Me.ToolStripStatusLabel1.Text = "Logged in As:"
        '
        'lblUserType
        '
        Me.lblUserType.Font = New System.Drawing.Font("Segoe UI Semibold", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblUserType.Image = Global.CAS_VB.My.Resources.Resources.images11
        Me.lblUserType.Name = "lblUserType"
        Me.lblUserType.Size = New System.Drawing.Size(96, 20)
        Me.lblUserType.Text = "User Type"
        '
        'ToolStripStatusLabel2
        '
        Me.ToolStripStatusLabel2.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ToolStripStatusLabel2.Name = "ToolStripStatusLabel2"
        Me.ToolStripStatusLabel2.Size = New System.Drawing.Size(13, 20)
        Me.ToolStripStatusLabel2.Text = ":"
        '
        'lblUser
        '
        Me.lblUser.Font = New System.Drawing.Font("Segoe UI Semibold", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblUser.Name = "lblUser"
        Me.lblUser.Size = New System.Drawing.Size(85, 20)
        Me.lblUser.Text = "User Name"
        '
        'ToolStripStatusLabel3
        '
        Me.ToolStripStatusLabel3.Name = "ToolStripStatusLabel3"
        Me.ToolStripStatusLabel3.Size = New System.Drawing.Size(737, 20)
        Me.ToolStripStatusLabel3.Spring = True
        '
        'lblDateTime
        '
        Me.lblDateTime.Font = New System.Drawing.Font("Segoe UI Semibold", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblDateTime.Image = Global.CAS_VB.My.Resources.Resources.Activate
        Me.lblDateTime.Name = "lblDateTime"
        Me.lblDateTime.Size = New System.Drawing.Size(98, 20)
        Me.lblDateTime.Text = "Date Time"
        '
        'ToolStripStatusLabel4
        '
        Me.ToolStripStatusLabel4.Name = "ToolStripStatusLabel4"
        Me.ToolStripStatusLabel4.Size = New System.Drawing.Size(17, 20)
        Me.ToolStripStatusLabel4.Text = "a"
        '
        'MenuStrip1
        '
        Me.MenuStrip1.Font = New System.Drawing.Font("Segoe UI", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.MenuStrip1.ImageScalingSize = New System.Drawing.Size(20, 20)
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.SchoolToolStripMenuItem, Me.DepartmentToolStripMenuItem, Me.LecturerToolStripMenuItem, Me.CourseToolStripMenuItem, Me.StudentsToolStripMenuItem, Me.ResultToolStripMenuItem, Me.ImportsToolStripMenuItem, Me.RecordsToolStripMenuItem, Me.UtilitiesToolStripMenuItem, Me.ToolsToolStripMenuItem, Me.ReportsToolStripMenuItem, Me.HelpToolStripMenuItem, Me.AboutToolStripMenuItem, Me.LogoutToolStripMenuItem})
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Size = New System.Drawing.Size(1162, 81)
        Me.MenuStrip1.TabIndex = 2
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'SchoolToolStripMenuItem
        '
        Me.SchoolToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.SchoolRegistrationToolStripMenuItem})
        Me.SchoolToolStripMenuItem.Image = Global.CAS_VB.My.Resources.Resources.university_icon
        Me.SchoolToolStripMenuItem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.SchoolToolStripMenuItem.Name = "SchoolToolStripMenuItem"
        Me.SchoolToolStripMenuItem.Size = New System.Drawing.Size(73, 77)
        Me.SchoolToolStripMenuItem.Text = "School"
        Me.SchoolToolStripMenuItem.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        '
        'SchoolRegistrationToolStripMenuItem
        '
        Me.SchoolRegistrationToolStripMenuItem.Name = "SchoolRegistrationToolStripMenuItem"
        Me.SchoolRegistrationToolStripMenuItem.Size = New System.Drawing.Size(233, 28)
        Me.SchoolRegistrationToolStripMenuItem.Text = "School Registration"
        '
        'DepartmentToolStripMenuItem
        '
        Me.DepartmentToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.DepartmentEntryToolStripMenuItem, Me.CourseStudyToolStripMenuItem})
        Me.DepartmentToolStripMenuItem.Image = Global.CAS_VB.My.Resources.Resources.Doc___Google_Docs
        Me.DepartmentToolStripMenuItem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.DepartmentToolStripMenuItem.Name = "DepartmentToolStripMenuItem"
        Me.DepartmentToolStripMenuItem.Size = New System.Drawing.Size(114, 77)
        Me.DepartmentToolStripMenuItem.Text = "Department"
        Me.DepartmentToolStripMenuItem.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        '
        'DepartmentEntryToolStripMenuItem
        '
        Me.DepartmentEntryToolStripMenuItem.Name = "DepartmentEntryToolStripMenuItem"
        Me.DepartmentEntryToolStripMenuItem.Size = New System.Drawing.Size(222, 28)
        Me.DepartmentEntryToolStripMenuItem.Text = "Department Entry"
        '
        'CourseStudyToolStripMenuItem
        '
        Me.CourseStudyToolStripMenuItem.Name = "CourseStudyToolStripMenuItem"
        Me.CourseStudyToolStripMenuItem.Size = New System.Drawing.Size(222, 28)
        Me.CourseStudyToolStripMenuItem.Text = "Course Study"
        '
        'LecturerToolStripMenuItem
        '
        Me.LecturerToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.LecturerEntryToolStripMenuItem})
        Me.LecturerToolStripMenuItem.Image = Global.CAS_VB.My.Resources.Resources.engineer_icon
        Me.LecturerToolStripMenuItem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.LecturerToolStripMenuItem.Name = "LecturerToolStripMenuItem"
        Me.LecturerToolStripMenuItem.Size = New System.Drawing.Size(84, 77)
        Me.LecturerToolStripMenuItem.Text = "Lecturer"
        Me.LecturerToolStripMenuItem.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        '
        'LecturerEntryToolStripMenuItem
        '
        Me.LecturerEntryToolStripMenuItem.Name = "LecturerEntryToolStripMenuItem"
        Me.LecturerEntryToolStripMenuItem.Size = New System.Drawing.Size(192, 28)
        Me.LecturerEntryToolStripMenuItem.Text = "Lecturer Entry"
        '
        'CourseToolStripMenuItem
        '
        Me.CourseToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.CourseRegistrationToolStripMenuItem})
        Me.CourseToolStripMenuItem.Image = Global.CAS_VB.My.Resources.Resources.custom_reports_icon
        Me.CourseToolStripMenuItem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.CourseToolStripMenuItem.Name = "CourseToolStripMenuItem"
        Me.CourseToolStripMenuItem.Size = New System.Drawing.Size(75, 77)
        Me.CourseToolStripMenuItem.Text = "Course"
        Me.CourseToolStripMenuItem.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        '
        'CourseRegistrationToolStripMenuItem
        '
        Me.CourseRegistrationToolStripMenuItem.Name = "CourseRegistrationToolStripMenuItem"
        Me.CourseRegistrationToolStripMenuItem.Size = New System.Drawing.Size(235, 28)
        Me.CourseRegistrationToolStripMenuItem.Text = "Course Registration"
        '
        'StudentsToolStripMenuItem
        '
        Me.StudentsToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.StudentEntryToolStripMenuItem})
        Me.StudentsToolStripMenuItem.Image = Global.CAS_VB.My.Resources.Resources.Student_3_icon
        Me.StudentsToolStripMenuItem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.StudentsToolStripMenuItem.Name = "StudentsToolStripMenuItem"
        Me.StudentsToolStripMenuItem.Size = New System.Drawing.Size(88, 77)
        Me.StudentsToolStripMenuItem.Text = "Students"
        Me.StudentsToolStripMenuItem.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        '
        'StudentEntryToolStripMenuItem
        '
        Me.StudentEntryToolStripMenuItem.Name = "StudentEntryToolStripMenuItem"
        Me.StudentEntryToolStripMenuItem.Size = New System.Drawing.Size(189, 28)
        Me.StudentEntryToolStripMenuItem.Text = "Student Entry"
        '
        'ResultToolStripMenuItem
        '
        Me.ResultToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ResultEntryToolStripMenuItem, Me.ResultsEntryToolStripMenuItem})
        Me.ResultToolStripMenuItem.Image = Global.CAS_VB.My.Resources.Resources.reports
        Me.ResultToolStripMenuItem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.ResultToolStripMenuItem.Name = "ResultToolStripMenuItem"
        Me.ResultToolStripMenuItem.Size = New System.Drawing.Size(110, 77)
        Me.ResultToolStripMenuItem.Text = "Attendance"
        Me.ResultToolStripMenuItem.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        '
        'ResultEntryToolStripMenuItem
        '
        Me.ResultEntryToolStripMenuItem.Name = "ResultEntryToolStripMenuItem"
        Me.ResultEntryToolStripMenuItem.Size = New System.Drawing.Size(218, 28)
        Me.ResultEntryToolStripMenuItem.Text = "Attendance Type"
        '
        'ResultsEntryToolStripMenuItem
        '
        Me.ResultsEntryToolStripMenuItem.Name = "ResultsEntryToolStripMenuItem"
        Me.ResultsEntryToolStripMenuItem.Size = New System.Drawing.Size(218, 28)
        Me.ResultsEntryToolStripMenuItem.Text = "Attendance Entry"
        '
        'ImportsToolStripMenuItem
        '
        Me.ImportsToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.MultipleToolStripMenuItem})
        Me.ImportsToolStripMenuItem.Image = Global.CAS_VB.My.Resources.Resources.add_stock
        Me.ImportsToolStripMenuItem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.ImportsToolStripMenuItem.Name = "ImportsToolStripMenuItem"
        Me.ImportsToolStripMenuItem.Size = New System.Drawing.Size(81, 77)
        Me.ImportsToolStripMenuItem.Text = "Imports"
        Me.ImportsToolStripMenuItem.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        '
        'MultipleToolStripMenuItem
        '
        Me.MultipleToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.CoursesToolStripMenuItem, Me.LecturersToolStripMenuItem, Me.ResultsToolStripMenuItem, Me.StudentsToolStripMenuItem1})
        Me.MultipleToolStripMenuItem.Name = "MultipleToolStripMenuItem"
        Me.MultipleToolStripMenuItem.Size = New System.Drawing.Size(148, 28)
        Me.MultipleToolStripMenuItem.Text = "Multiple"
        '
        'CoursesToolStripMenuItem
        '
        Me.CoursesToolStripMenuItem.Name = "CoursesToolStripMenuItem"
        Me.CoursesToolStripMenuItem.Size = New System.Drawing.Size(155, 28)
        Me.CoursesToolStripMenuItem.Text = "Courses"
        Me.CoursesToolStripMenuItem.Visible = False
        '
        'LecturersToolStripMenuItem
        '
        Me.LecturersToolStripMenuItem.Name = "LecturersToolStripMenuItem"
        Me.LecturersToolStripMenuItem.Size = New System.Drawing.Size(155, 28)
        Me.LecturersToolStripMenuItem.Text = "Lecturers"
        Me.LecturersToolStripMenuItem.Visible = False
        '
        'ResultsToolStripMenuItem
        '
        Me.ResultsToolStripMenuItem.Name = "ResultsToolStripMenuItem"
        Me.ResultsToolStripMenuItem.Size = New System.Drawing.Size(155, 28)
        Me.ResultsToolStripMenuItem.Text = "Results"
        Me.ResultsToolStripMenuItem.Visible = False
        '
        'StudentsToolStripMenuItem1
        '
        Me.StudentsToolStripMenuItem1.Name = "StudentsToolStripMenuItem1"
        Me.StudentsToolStripMenuItem1.Size = New System.Drawing.Size(155, 28)
        Me.StudentsToolStripMenuItem1.Text = "Students"
        '
        'RecordsToolStripMenuItem
        '
        Me.RecordsToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.CoursesToolStripMenuItem1, Me.LecturersToolStripMenuItem1, Me.ResultsToolStripMenuItem1, Me.StudentsToolStripMenuItem2})
        Me.RecordsToolStripMenuItem.Image = Global.CAS_VB.My.Resources.Resources.reports_icon
        Me.RecordsToolStripMenuItem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.RecordsToolStripMenuItem.Name = "RecordsToolStripMenuItem"
        Me.RecordsToolStripMenuItem.Size = New System.Drawing.Size(82, 77)
        Me.RecordsToolStripMenuItem.Text = "Records"
        Me.RecordsToolStripMenuItem.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        '
        'CoursesToolStripMenuItem1
        '
        Me.CoursesToolStripMenuItem1.Name = "CoursesToolStripMenuItem1"
        Me.CoursesToolStripMenuItem1.Size = New System.Drawing.Size(174, 28)
        Me.CoursesToolStripMenuItem1.Text = "Courses"
        Me.CoursesToolStripMenuItem1.Visible = False
        '
        'LecturersToolStripMenuItem1
        '
        Me.LecturersToolStripMenuItem1.Name = "LecturersToolStripMenuItem1"
        Me.LecturersToolStripMenuItem1.Size = New System.Drawing.Size(174, 28)
        Me.LecturersToolStripMenuItem1.Text = "Lecturers"
        Me.LecturersToolStripMenuItem1.Visible = False
        '
        'ResultsToolStripMenuItem1
        '
        Me.ResultsToolStripMenuItem1.Name = "ResultsToolStripMenuItem1"
        Me.ResultsToolStripMenuItem1.Size = New System.Drawing.Size(174, 28)
        Me.ResultsToolStripMenuItem1.Text = "Attendance"
        '
        'StudentsToolStripMenuItem2
        '
        Me.StudentsToolStripMenuItem2.Name = "StudentsToolStripMenuItem2"
        Me.StudentsToolStripMenuItem2.Size = New System.Drawing.Size(174, 28)
        Me.StudentsToolStripMenuItem2.Text = "Students"
        '
        'UtilitiesToolStripMenuItem
        '
        Me.UtilitiesToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.UserRegistrationToolStripMenuItem, Me.ChangePasswordToolStripMenuItem, Me.TransferStudentsToolStripMenuItem})
        Me.UtilitiesToolStripMenuItem.Image = Global.CAS_VB.My.Resources.Resources.Utilities_icon
        Me.UtilitiesToolStripMenuItem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.UtilitiesToolStripMenuItem.Name = "UtilitiesToolStripMenuItem"
        Me.UtilitiesToolStripMenuItem.Size = New System.Drawing.Size(78, 77)
        Me.UtilitiesToolStripMenuItem.Text = "Utilities"
        Me.UtilitiesToolStripMenuItem.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        '
        'UserRegistrationToolStripMenuItem
        '
        Me.UserRegistrationToolStripMenuItem.Image = Global.CAS_VB.My.Resources.Resources.new_customers
        Me.UserRegistrationToolStripMenuItem.Name = "UserRegistrationToolStripMenuItem"
        Me.UserRegistrationToolStripMenuItem.Size = New System.Drawing.Size(220, 28)
        Me.UserRegistrationToolStripMenuItem.Text = "User Registration"
        '
        'ChangePasswordToolStripMenuItem
        '
        Me.ChangePasswordToolStripMenuItem.Image = Global.CAS_VB.My.Resources.Resources.unnamed
        Me.ChangePasswordToolStripMenuItem.Name = "ChangePasswordToolStripMenuItem"
        Me.ChangePasswordToolStripMenuItem.Size = New System.Drawing.Size(220, 28)
        Me.ChangePasswordToolStripMenuItem.Text = "Change Password"
        '
        'TransferStudentsToolStripMenuItem
        '
        Me.TransferStudentsToolStripMenuItem.Image = Global.CAS_VB.My.Resources.Resources.images_6
        Me.TransferStudentsToolStripMenuItem.Name = "TransferStudentsToolStripMenuItem"
        Me.TransferStudentsToolStripMenuItem.Size = New System.Drawing.Size(220, 28)
        Me.TransferStudentsToolStripMenuItem.Text = "Transfer Students"
        '
        'ToolsToolStripMenuItem
        '
        Me.ToolsToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.CalculatorToolStripMenuItem, Me.NotepadToolStripMenuItem, Me.MSWordToolStripMenuItem, Me.WordToolStripMenuItem, Me.TaskManagerToolStripMenuItem})
        Me.ToolsToolStripMenuItem.Image = Global.CAS_VB.My.Resources.Resources.Utilities_icon__1_
        Me.ToolsToolStripMenuItem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.ToolsToolStripMenuItem.Name = "ToolsToolStripMenuItem"
        Me.ToolsToolStripMenuItem.Size = New System.Drawing.Size(60, 77)
        Me.ToolsToolStripMenuItem.Text = "Tools"
        Me.ToolsToolStripMenuItem.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        '
        'CalculatorToolStripMenuItem
        '
        Me.CalculatorToolStripMenuItem.Image = Global.CAS_VB.My.Resources.Resources.calc
        Me.CalculatorToolStripMenuItem.Name = "CalculatorToolStripMenuItem"
        Me.CalculatorToolStripMenuItem.Size = New System.Drawing.Size(190, 28)
        Me.CalculatorToolStripMenuItem.Text = "Calculator"
        '
        'NotepadToolStripMenuItem
        '
        Me.NotepadToolStripMenuItem.Image = Global.CAS_VB.My.Resources.Resources.Notepad1
        Me.NotepadToolStripMenuItem.Name = "NotepadToolStripMenuItem"
        Me.NotepadToolStripMenuItem.Size = New System.Drawing.Size(190, 28)
        Me.NotepadToolStripMenuItem.Text = "Notepad"
        '
        'MSWordToolStripMenuItem
        '
        Me.MSWordToolStripMenuItem.Image = Global.CAS_VB.My.Resources.Resources.MS_Word_2_icon1
        Me.MSWordToolStripMenuItem.Name = "MSWordToolStripMenuItem"
        Me.MSWordToolStripMenuItem.Size = New System.Drawing.Size(190, 28)
        Me.MSWordToolStripMenuItem.Text = "MS Word"
        '
        'WordToolStripMenuItem
        '
        Me.WordToolStripMenuItem.Image = Global.CAS_VB.My.Resources.Resources.Wordpad_icon__Windows_7_
        Me.WordToolStripMenuItem.Name = "WordToolStripMenuItem"
        Me.WordToolStripMenuItem.Size = New System.Drawing.Size(190, 28)
        Me.WordToolStripMenuItem.Text = "Word Pad"
        '
        'TaskManagerToolStripMenuItem
        '
        Me.TaskManagerToolStripMenuItem.Image = Global.CAS_VB.My.Resources.Resources.task_manager1
        Me.TaskManagerToolStripMenuItem.Name = "TaskManagerToolStripMenuItem"
        Me.TaskManagerToolStripMenuItem.Size = New System.Drawing.Size(190, 28)
        Me.TaskManagerToolStripMenuItem.Text = "Task Manager"
        '
        'ReportsToolStripMenuItem
        '
        Me.ReportsToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.CoursesToolStripMenuItem2, Me.LecturersToolStripMenuItem2, Me.ResultsToolStripMenuItem2, Me.StudentsToolStripMenuItem4})
        Me.ReportsToolStripMenuItem.Image = Global.CAS_VB.My.Resources.Resources.custom_reports_icon
        Me.ReportsToolStripMenuItem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.ReportsToolStripMenuItem.Name = "ReportsToolStripMenuItem"
        Me.ReportsToolStripMenuItem.Size = New System.Drawing.Size(80, 77)
        Me.ReportsToolStripMenuItem.Text = "Reports"
        Me.ReportsToolStripMenuItem.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        '
        'CoursesToolStripMenuItem2
        '
        Me.CoursesToolStripMenuItem2.Name = "CoursesToolStripMenuItem2"
        Me.CoursesToolStripMenuItem2.Size = New System.Drawing.Size(174, 28)
        Me.CoursesToolStripMenuItem2.Text = "Courses"
        Me.CoursesToolStripMenuItem2.Visible = False
        '
        'LecturersToolStripMenuItem2
        '
        Me.LecturersToolStripMenuItem2.Name = "LecturersToolStripMenuItem2"
        Me.LecturersToolStripMenuItem2.Size = New System.Drawing.Size(174, 28)
        Me.LecturersToolStripMenuItem2.Text = "Lecturers"
        Me.LecturersToolStripMenuItem2.Visible = False
        '
        'ResultsToolStripMenuItem2
        '
        Me.ResultsToolStripMenuItem2.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.StudentsToolStripMenuItem3, Me.CourseToolStripMenuItem1, Me.OverallToolStripMenuItem})
        Me.ResultsToolStripMenuItem2.Image = Global.CAS_VB.My.Resources.Resources.Clipboard_icon
        Me.ResultsToolStripMenuItem2.Name = "ResultsToolStripMenuItem2"
        Me.ResultsToolStripMenuItem2.Size = New System.Drawing.Size(174, 28)
        Me.ResultsToolStripMenuItem2.Text = "Attendance"
        '
        'StudentsToolStripMenuItem3
        '
        Me.StudentsToolStripMenuItem3.Name = "StudentsToolStripMenuItem3"
        Me.StudentsToolStripMenuItem3.Size = New System.Drawing.Size(145, 28)
        Me.StudentsToolStripMenuItem3.Text = "Student"
        Me.StudentsToolStripMenuItem3.Visible = False
        '
        'CourseToolStripMenuItem1
        '
        Me.CourseToolStripMenuItem1.Name = "CourseToolStripMenuItem1"
        Me.CourseToolStripMenuItem1.Size = New System.Drawing.Size(145, 28)
        Me.CourseToolStripMenuItem1.Text = "Course"
        '
        'OverallToolStripMenuItem
        '
        Me.OverallToolStripMenuItem.Name = "OverallToolStripMenuItem"
        Me.OverallToolStripMenuItem.Size = New System.Drawing.Size(145, 28)
        Me.OverallToolStripMenuItem.Text = "Overall"
        Me.OverallToolStripMenuItem.Visible = False
        '
        'StudentsToolStripMenuItem4
        '
        Me.StudentsToolStripMenuItem4.Name = "StudentsToolStripMenuItem4"
        Me.StudentsToolStripMenuItem4.Size = New System.Drawing.Size(174, 28)
        Me.StudentsToolStripMenuItem4.Text = "Students"
        Me.StudentsToolStripMenuItem4.Visible = False
        '
        'HelpToolStripMenuItem
        '
        Me.HelpToolStripMenuItem.Image = Global.CAS_VB.My.Resources.Resources.help_icon
        Me.HelpToolStripMenuItem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.HelpToolStripMenuItem.Name = "HelpToolStripMenuItem"
        Me.HelpToolStripMenuItem.Size = New System.Drawing.Size(60, 77)
        Me.HelpToolStripMenuItem.Text = "Help"
        Me.HelpToolStripMenuItem.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        Me.HelpToolStripMenuItem.Visible = False
        '
        'AboutToolStripMenuItem
        '
        Me.AboutToolStripMenuItem.Image = Global.CAS_VB.My.Resources.Resources.Actions_help_about_icon
        Me.AboutToolStripMenuItem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.AboutToolStripMenuItem.Name = "AboutToolStripMenuItem"
        Me.AboutToolStripMenuItem.Size = New System.Drawing.Size(69, 77)
        Me.AboutToolStripMenuItem.Text = "About"
        Me.AboutToolStripMenuItem.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        '
        'LogoutToolStripMenuItem
        '
        Me.LogoutToolStripMenuItem.Image = Global.CAS_VB.My.Resources.Resources.Logout_icon
        Me.LogoutToolStripMenuItem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.LogoutToolStripMenuItem.Name = "LogoutToolStripMenuItem"
        Me.LogoutToolStripMenuItem.Size = New System.Drawing.Size(76, 77)
        Me.LogoutToolStripMenuItem.Text = "Logout"
        Me.LogoutToolStripMenuItem.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        '
        'Timer1
        '
        Me.Timer1.Enabled = True
        '
        'Timer2
        '
        '
        'PictureBox1
        '
        Me.PictureBox1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.PictureBox1.Image = CType(resources.GetObject("PictureBox1.Image"), System.Drawing.Image)
        Me.PictureBox1.Location = New System.Drawing.Point(0, 81)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(1162, 606)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox1.TabIndex = 4
        Me.PictureBox1.TabStop = False
        '
        'frmMain
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1162, 712)
        Me.Controls.Add(Me.PictureBox1)
        Me.Controls.Add(Me.StatusStrip1)
        Me.Controls.Add(Me.MenuStrip1)
        Me.Name = "frmMain"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "COLLEGE ATTENDANCE SYSTEM (CAS)"
        Me.WindowState = System.Windows.Forms.FormWindowState.Maximized
        Me.StatusStrip1.ResumeLayout(False)
        Me.StatusStrip1.PerformLayout()
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents StatusStrip1 As StatusStrip
    Friend WithEvents ToolStripStatusLabel1 As ToolStripStatusLabel
    Friend WithEvents lblUserType As ToolStripStatusLabel
    Friend WithEvents ToolStripStatusLabel2 As ToolStripStatusLabel
    Friend WithEvents lblUser As ToolStripStatusLabel
    Friend WithEvents ToolStripStatusLabel3 As ToolStripStatusLabel
    Friend WithEvents lblDateTime As ToolStripStatusLabel
    Friend WithEvents ToolStripStatusLabel4 As ToolStripStatusLabel
    Friend WithEvents MenuStrip1 As MenuStrip
    Friend WithEvents SchoolToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents SchoolRegistrationToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents DepartmentToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents DepartmentEntryToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents CourseStudyToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents LecturerToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents LecturerEntryToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents CourseToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents CourseRegistrationToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents StudentsToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents StudentEntryToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ResultToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ResultEntryToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ResultsEntryToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ImportsToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents MultipleToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents CoursesToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents LecturersToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ResultsToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents StudentsToolStripMenuItem1 As ToolStripMenuItem
    Friend WithEvents RecordsToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents CoursesToolStripMenuItem1 As ToolStripMenuItem
    Friend WithEvents LecturersToolStripMenuItem1 As ToolStripMenuItem
    Friend WithEvents ResultsToolStripMenuItem1 As ToolStripMenuItem
    Friend WithEvents StudentsToolStripMenuItem2 As ToolStripMenuItem
    Friend WithEvents UtilitiesToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents UserRegistrationToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ChangePasswordToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ToolsToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents CalculatorToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents NotepadToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents MSWordToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents WordToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents TaskManagerToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ReportsToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents CoursesToolStripMenuItem2 As ToolStripMenuItem
    Friend WithEvents LecturersToolStripMenuItem2 As ToolStripMenuItem
    Friend WithEvents ResultsToolStripMenuItem2 As ToolStripMenuItem
    Friend WithEvents StudentsToolStripMenuItem3 As ToolStripMenuItem
    Friend WithEvents CourseToolStripMenuItem1 As ToolStripMenuItem
    Friend WithEvents OverallToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents StudentsToolStripMenuItem4 As ToolStripMenuItem
    Friend WithEvents HelpToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents AboutToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents LogoutToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents Timer1 As Timer
    Friend WithEvents Timer2 As Timer
    Friend WithEvents TransferStudentsToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents PictureBox1 As PictureBox
End Class
